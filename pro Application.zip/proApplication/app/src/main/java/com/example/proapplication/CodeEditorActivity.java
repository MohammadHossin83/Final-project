package com.example.proapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.proapplication.models.Lesson;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class CodeEditorActivity extends AppCompatActivity {
    EditText codeInput;
    Button submitCode;
    Lesson lesson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_editor);

        codeInput = findViewById(R.id.code_input);
        submitCode = findViewById(R.id.submit_code_btn);

        lesson = (Lesson) getIntent().getSerializableExtra("lesson");

        submitCode.setOnClickListener(v -> {
            String userCode = codeInput.getText().toString();
            checkCodeOnServer(userCode, lesson.expectedOutput);
        });
    }

    private void checkCodeOnServer(String code, String expectedOutput) {
        String url = "https://mohamad168.pythonanywhere.com/check_code";

        StringRequest request = new StringRequest(
                Request.Method.POST,
                url,
                response -> {

                    boolean result = response.contains("\"result\":true");
                    String output = response.contains("output") ? response.split("output\":\"")[1].split("\"")[0] : "";

                    Intent intent = new Intent(this, ResultActivity.class);
                    intent.putExtra("result", result);
                    intent.putExtra("output", output);
                    startActivity(intent);
                },
                error -> {
                    Toast.makeText(this, "❌ خطا در ارتباط با سرور", Toast.LENGTH_LONG).show();
                }
        ) {
            @Override
            public byte[] getBody() {
                try {
                    String data = "code=" + URLEncoder.encode(code, "UTF-8") +
                            "&expected_output=" + URLEncoder.encode(expectedOutput, "UTF-8");
                    return data.getBytes();
                } catch (UnsupportedEncodingException e) {
                    return null;
                }
            }

            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded; charset=UTF-8";
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }
}
