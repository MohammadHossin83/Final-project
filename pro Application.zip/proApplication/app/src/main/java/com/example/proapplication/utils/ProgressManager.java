package com.example.proapplication.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.proapplication.models.Lesson;

import java.util.Map;

public class ProgressManager {
    public static void updateProgress(Context context, String lessonTitle, boolean isCorrect) {
        SharedPreferences prefs = context.getSharedPreferences("progress", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(lessonTitle, isCorrect);
        editor.apply();
    }

    public static int getProgress(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("progress", Context.MODE_PRIVATE);
        Map<String, ?> all = prefs.getAll();
        int correct = 0;
        for (Object val : all.values()) {
            if ((boolean) val) correct++;
        }
        return (int) ((correct / (float) Lesson.getSampleLessons().size()) * 100);
    }
}
