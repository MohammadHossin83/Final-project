package com.example.proapplication.utils;

public class CodeChecker {
    public static boolean checkCode(String userCode, String expectedOutput) {
        String fakeOutput = simulateExecution(userCode);
        return fakeOutput.trim().equals(expectedOutput.trim());
    }

    private static String simulateExecution(String code) {
        if(code.contains("print('Hello')")) return "Hello";
        return "";
    }
}
