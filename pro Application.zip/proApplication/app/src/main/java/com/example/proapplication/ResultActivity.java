package com.example.proapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;

import java.util.ArrayList;

public class ResultActivity extends AppCompatActivity {

    TextView resultText;
    Button backButton;
    ProgressBar progressBar;
    PieChart pieChart;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        resultText = findViewById(R.id.resultText);
        backButton = findViewById(R.id.backButton);
        progressBar = findViewById(R.id.progressBar);
        pieChart = findViewById(R.id.pieChart);

        progressBar.setVisibility(View.GONE);
        pieChart.setVisibility(View.GONE);


        boolean result = getIntent().getBooleanExtra("result", false);
        String output = getIntent().getStringExtra("output");


        resultText.setText(
                result ? "✅ پاسخ صحیح است!\n\n" + output
                        : "❌ پاسخ نادرست است!\n\n" + output
        );


        backButton.setOnClickListener(v -> finish());


        showPieChart(result);
    }

    private void showPieChart(boolean isCorrect) {
        float correctPercent = isCorrect ? 80f : 30f;

        ArrayList<PieEntry> entries = new ArrayList<>();
        entries.add(new PieEntry(correctPercent, "درست"));
        entries.add(new PieEntry(100 - correctPercent, "اشتباه"));

        PieDataSet dataSet = new PieDataSet(entries, "تحلیل کد");
        dataSet.setColors(new int[]{Color.parseColor("#018786"), Color.parseColor("#BB86FC")});
        dataSet.setValueTextSize(14f);
        dataSet.setValueTextColor(Color.BLACK);

        PieData pieData = new PieData(dataSet);

        pieChart.setData(pieData);
        Description description = new Description();
        description.setText("نتیجه بررسی");
        pieChart.setDescription(description);
        pieChart.setUsePercentValues(true);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setTransparentCircleRadius(40f);
        pieChart.setHoleRadius(30f);

        pieChart.invalidate();
        pieChart.setVisibility(View.VISIBLE);
    }
}
