package com.example.proapplication.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.proapplication.LessonActivity;
import com.example.proapplication.R;
import com.example.proapplication.models.Lesson;

import java.util.List;

public class LessonAdapter extends RecyclerView.Adapter<LessonAdapter.LessonViewHolder> {
    List<Lesson> lessons;
    Context context;

    public LessonAdapter(List<Lesson> lessons, Context context) {
        this.lessons = lessons;
        this.context = context;
    }

    @Override
    public LessonViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_lesson, parent, false);
        return new LessonViewHolder(view);
    }

    @Override
    public void onBindViewHolder(LessonViewHolder holder, int position) {
        Lesson lesson = lessons.get(position);
        holder.title.setText(lesson.title);
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, LessonActivity.class);
            intent.putExtra("lesson", lesson);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return lessons.size();
    }

    class LessonViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        public LessonViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.lesson_title);
        }
    }
}
