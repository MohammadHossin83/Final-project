package com.example.proapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proapplication.adapters.LessonAdapter;
import com.example.proapplication.models.Lesson;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView lessonList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lessonList = findViewById(R.id.lesson_list);
        lessonList.setLayoutManager(new LinearLayoutManager(this));

        List<Lesson> lessons = Lesson.getSampleLessons();
        LessonAdapter adapter = new LessonAdapter(lessons, this);
        lessonList.setAdapter(adapter);
    }
}