package com.example.proapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.proapplication.models.Lesson;

public class LessonActivity extends AppCompatActivity {
    TextView lessonContent;
    Button startCoding;
    Lesson lesson;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lesson);

        lesson = (Lesson) getIntent().getSerializableExtra("lesson");
        lessonContent = findViewById(R.id.lesson_content);
        startCoding = findViewById(R.id.start_coding_btn);

        lessonContent.setText(lesson.content + "\n\nمثال:\n" + lesson.exampleCode);

        startCoding.setOnClickListener(v -> {
            Intent intent = new Intent(this, CodeEditorActivity.class);
            intent.putExtra("lesson", lesson);
            startActivity(intent);
        });
    }
}