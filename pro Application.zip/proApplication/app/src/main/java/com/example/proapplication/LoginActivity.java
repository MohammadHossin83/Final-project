package com.example.proapplication;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText username, password;
    Button loginBtn;
    LinearLayout headerBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginBtn = findViewById(R.id.loginBtn);
        headerBox = findViewById(R.id.headerBox);

        loginBtn.setOnClickListener(v -> {
            String user = username.getText().toString().trim();
            String pass = password.getText().toString().trim();

            if (user.equals("admin") && pass.equals("1234")) {

                playSoundAndAnimate();
            } else {
                Toast.makeText(this, "❌ نام کاربری یا رمز عبور اشتباه است", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void playSoundAndAnimate() {
        // پخش صدای sms.mp3 از res/raw
        MediaPlayer mp = MediaPlayer.create(this, R.raw.sms);
        mp.start();

        Animation animation = AnimationUtils.loadAnimation(this, R.anim.scale_logo);
        headerBox.startAnimation(animation);

        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override public void onAnimationStart(Animation animation) {}
            @Override public void onAnimationRepeat(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
