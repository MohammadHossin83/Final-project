package com.example.proapplication.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Lesson implements Serializable {
    public String title, content, exampleCode, testInput, expectedOutput;

    public Lesson(String title, String content, String exampleCode, String testInput, String expectedOutput) {
        this.title = title;
        this.content = content;
        this.exampleCode = exampleCode;
        this.testInput = testInput;
        this.expectedOutput = expectedOutput;
    }

    public static List<Lesson> getSampleLessons() {
        List<Lesson> lessons = new ArrayList<>();
        lessons.add(new Lesson("درس ۱: چاپ ساده", "در این درس با print آشنا می‌شوید.",
                "print('Hello')", "", "Hello"));
        lessons.add(new Lesson("درس ۲: جمع دو عدد", "با جمع کردن عدد آشنا شوید.",
                "a = 2\nb = 3\nprint(a + b)", "", "5"));
        return lessons;
    }
}
